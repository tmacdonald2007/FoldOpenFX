package com.tmacdonald2007.foldopenfx

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class FoldFxService : Service(), SensorEventListener {
    private lateinit var windowManager: WindowManager
    private lateinit var overlay: FoldFxOverlay
    private lateinit var sensorManager: SensorManager
    private var hingeSensor: Sensor? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val n = notification()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(42, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(42, n)

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        hingeSensor = sensorManager.getDefaultSensor(Sensor.TYPE_HINGE_ANGLE)
        overlay = FoldFxOverlay(this)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            android.graphics.PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        if (Settings.canDrawOverlays(this))
            runCatching { windowManager.addView(overlay, params) }
                .onFailure { overlay.errorMessage = "OVERLAY ERROR" }
        else overlay.errorMessage = "OVERLAY PERMISSION OFF"

        if (hingeSensor != null) {
            sensorManager.registerListener(this, hingeSensor, SensorManager.SENSOR_DELAY_GAME)
        } else overlay.sensorMessage = "NO HINGE SENSOR"
    }

    override fun onDestroy() {
        if (::sensorManager.isInitialized) sensorManager.unregisterListener(this)
        if (::overlay.isInitialized) runCatching { windowManager.removeView(overlay) }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type == Sensor.TYPE_HINGE_ANGLE)
            overlay.updateHingeAngle(event.values.firstOrNull() ?: 180f)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                "foldopenfx", "FoldOpenFX", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(): Notification {
        val b = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, "foldopenfx") else Notification.Builder(this)
        return b.setContentTitle("FoldOpenFX active")
            .setContentText("Fold animation is running")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true).build()
    }
}

private class FoldFxOverlay(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gradientPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var hingeAngle = 180f
    private var lastAngle = 180f
    private var lastTime = 0L
    private var motion = 0f
    private var hideAt = 0L

    var sensorMessage = ""
        set(value) { field = value; invalidate() }
    var errorMessage = ""
        set(value) { field = value; invalidate() }

    fun updateHingeAngle(value: Float) {
        val now = SystemClock.elapsedRealtime()
        val next = value.coerceIn(0f, 180f)
        if (lastTime != 0L) {
            val dt = max(1L, now - lastTime)
            val delta = next - lastAngle
            if (abs(delta) > 0.12f) {
                motion = min(1f, abs(delta) / 2.0f)
                hideAt = now + 180L
            } else motion *= 0.90f
            val speed = abs(delta) * 1000f / dt
            motion = max(motion, min(1f, speed / 130f))
        }
        hingeAngle = next
        lastAngle = next
        lastTime = now
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val now = SystemClock.elapsedRealtime()
        if (now > hideAt && motion < 0.025f) return

        val center = width / 2f
        val closed = 1f - (hingeAngle / 180f).coerceIn(0f, 1f)
        val fade = if (now <= hideAt) 1f else max(0f, motion * 0.85f)
        val crease = 12f + closed * 32f
        val reach = 85f + closed * 145f

        val glowAlpha = (110f * fade).toInt().coerceIn(0, 180)
        gradientPaint.shader = LinearGradient(
            center - crease * 3f, 0f, center + crease * 3f, 0f,
            Color.argb(0,255,255,255),
            Color.argb(glowAlpha,255,255,255),
            Color.argb(0,255,255,255),
            Shader.TileMode.CLAMP)
        canvas.drawRect(center - crease*3f,0f,center + crease*3f,height.toFloat(),gradientPaint)
        gradientPaint.shader = null

        val alpha = (72f * fade * (0.35f + closed * 0.65f)).toInt().coerceIn(0,100)
        drawPanel(canvas, center, -1f, crease, reach, alpha)
        drawPanel(canvas, center, 1f, crease, reach, alpha)

        paint.color = Color.argb((145f*fade).toInt().coerceIn(0,220),255,255,255)
        canvas.drawRect(center-1.25f,0f,center+1.25f,height.toFloat(),paint)

        paint.color = Color.argb((100f*fade).toInt().coerceIn(0,150),0,0,0)
        canvas.drawRect(center-5f,0f,center-1.25f,height.toFloat(),paint)
        canvas.drawRect(center+1.25f,0f,center+5f,height.toFloat(),paint)

        if (motion > 0.02f || now <= hideAt) postInvalidateDelayed(16L)
        motion *= 0.985f
    }

    private fun drawPanel(canvas: Canvas, center: Float, side: Float,
                          crease: Float, reach: Float, alpha: Int) {
        val inner = center + side * crease
        val outer = center + side * (crease + reach)
        gradientPaint.shader = LinearGradient(
            inner,0f,outer,0f,
            Color.argb(alpha,245,245,255),
            Color.argb((alpha*0.38f).toInt(),255,255,255),
            Color.argb(0,255,255,255), Shader.TileMode.CLAMP)
        canvas.drawRect(min(inner,outer),0f,max(inner,outer),height.toFloat(),gradientPaint)
        gradientPaint.shader = null

        val perspective = min(18f, reach*0.10f)
        path.reset()
        if (side < 0f) {
            path.moveTo(inner,0f); path.lineTo(outer,perspective)
            path.lineTo(outer,height-perspective); path.lineTo(inner,height.toFloat())
        } else {
            path.moveTo(inner,0f); path.lineTo(outer,-perspective)
            path.lineTo(outer,height+perspective); path.lineTo(inner,height.toFloat())
        }
        path.close()
        paint.color = Color.argb((alpha*0.20f).toInt().coerceIn(0,40),255,255,255)
        canvas.drawPath(path,paint)
    }
}
