package com.tmacdonald2007.foldopenfx

import android.app.*
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.*
import android.graphics.*
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.content.pm.ServiceInfo
import android.provider.Settings
import android.view.*
import android.widget.ImageView
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class FoldFxService : Service(), SensorEventListener {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CH = "foldfx"
        private const val NOTIF = 7
        private const val ANIM_MS = 780L
    }

    private lateinit var sensorManager: SensorManager
    private var hinge: Sensor? = null
    private var lastAngle = 180f
    private var moving = false

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var virtualDisplay: android.hardware.display.VirtualDisplay? = null
    private var latestBitmap: Bitmap? = null

    private var wm: WindowManager? = null
    private var overlay: FoldOverlay? = null
    private var animator: ValueAnimator? = null
    private var lastTrigger = 0L
    private var animationRunning = false
    private var frozenBitmap: Bitmap? = null
    private var displayManager: DisplayManager? = null
    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) = Unit
        override fun onDisplayRemoved(displayId: Int) {
            if (animationRunning) scheduleOverlayReattach()
        }
        override fun onDisplayChanged(displayId: Int) {
            if (animationRunning) scheduleOverlayReattach()
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF, notification())
        }
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        displayManager = getSystemService(DisplayManager::class.java)
        displayManager?.registerDisplayListener(displayListener, Handler(Looper.getMainLooper()))
        hinge = sensorManager.getDefaultSensor(Sensor.TYPE_HINGE_ANGLE)
        if (hinge != null) sensorManager.registerListener(this, hinge, SensorManager.SENSOR_DELAY_GAME)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra(EXTRA_RESULT_CODE, -1) ?: -1
        val data = intent?.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
        if (code != -1 && data != null && projection == null) startCapture(code, data)
        return START_STICKY
    }

    private fun startCapture(code: Int, data: Intent) {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        projection = mpm.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                // Samsung may stop/reconfigure MediaProjection during the inner/cover display handoff.
                // Do not touch an already-running animation; its frozen Bitmap is independent.
                stopCapture()
            }
        }, Handler(Looper.getMainLooper()))

        val metrics = resources.displayMetrics
        val w = metrics.widthPixels
        val h = metrics.heightPixels
        if (w <= 0 || h <= 0) return

        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        reader!!.setOnImageAvailableListener({ ir ->
            val image = ir.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val plane = image.planes[0]
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val rowPadding = rowStride - pixelStride * w
                val paddedWidth = w + rowPadding / pixelStride

                val raw = Bitmap.createBitmap(paddedWidth, h, Bitmap.Config.ARGB_8888)
                raw.copyPixelsFromBuffer(plane.buffer)
                val b = if (paddedWidth != w) {
                    Bitmap.createBitmap(raw, 0, 0, w, h).copy(Bitmap.Config.ARGB_8888, false).also {
                        raw.recycle()
                    }
                } else {
                    raw
                }

                synchronized(this) {
                    latestBitmap?.recycle()
                    latestBitmap = b
                }
            } catch (_: Throwable) {
                // Keep the previous good frame. The next image will be tried again.
            } finally {
                image.close()
            }
        }, Handler(Looper.getMainLooper()))

        virtualDisplay = projection!!.createVirtualDisplay(
            "FoldOpenFXCapture", w, h, metrics.densityDpi,
            android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, null
        )
    }

    override fun onSensorChanged(e: SensorEvent) {
        val angle = e.values[0]
        val delta = abs(angle - lastAngle)

        if (delta > 0.45f) {
            if (!moving) {
                moving = true
                val now = SystemClock.uptimeMillis()
                if (now - lastTrigger > 350L && !animationRunning) {
                    lastTrigger = now
                    val opening = angle > lastAngle
                    // Freeze the newest frame BEFORE Samsung changes displays.
                    val bmp = synchronized(this) {
                        latestBitmap?.copy(Bitmap.Config.ARGB_8888, false)
                    }
                    if (bmp != null) animateSnapshot(bmp, opening)
                }
            }
        } else if (moving && delta < 0.12f) {
            moving = false
        }
        lastAngle = angle
    }

    private fun animateSnapshot(bitmap: Bitmap, opening: Boolean) {
        if (!Settings.canDrawOverlays(this)) {
            bitmap.recycle()
            return
        }
        Handler(Looper.getMainLooper()).post {
            animator?.cancel()
            overlay?.let { removeOverlay(it) }

            frozenBitmap?.recycle()
            frozenBitmap = bitmap

            val ov = FoldOverlay(this, frozenBitmap!!)
            overlay = ov
            wm = getSystemService(WINDOW_SERVICE) as WindowManager
            animationRunning = true

            attachOverlay(ov)

            val startValue = if (opening) 0f else 1f
            val endValue = if (opening) 1f else 0f
            animator = ValueAnimator.ofFloat(startValue, endValue).apply {
                duration = ANIM_MS
                interpolator = android.view.animation.PathInterpolator(0.18f, 0.9f, 0.22f, 1f)
                addUpdateListener { a ->
                    ov.progress = a.animatedValue as Float
                    ov.invalidate()
                }
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator) {
                        animationRunning = false
                        removeOverlay(ov)
                        frozenBitmap?.recycle()
                        frozenBitmap = null
                    }
                    override fun onAnimationCancel(animation: Animator) {
                        animationRunning = false
                    }
                })
                start()
            }
        }
    }

    private fun attachOverlay(v: View) {
        val manager = wm ?: return
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        p.title = "FoldOpenFX transition"
        if (Build.VERSION.SDK_INT >= 28) {
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
        try {
            manager.addView(v, p)
        } catch (_: Throwable) {
            // The display may be in the middle of Samsung's inner/cover handoff.
            // The display listener will retry while the animation is active.
        }
    }

    private fun scheduleOverlayReattach() {
        Handler(Looper.getMainLooper()).postDelayed({
            if (!animationRunning || frozenBitmap == null) return@postDelayed
            val current = overlay
            if (current != null) {
                try { wm?.removeViewImmediate(current) } catch (_: Throwable) {}
                if (overlay === current) overlay = null
            }
            val replacement = FoldOverlay(this, frozenBitmap!!)
            replacement.progress = animator?.animatedValue as? Float ?: replacement.progress
            overlay = replacement
            attachOverlay(replacement)
            replacement.invalidate()
        }, 35L)
    }

    private fun removeOverlay(v: View) {
        try { wm?.removeViewImmediate(v) } catch (_: Throwable) {}
        if (overlay === v) overlay = null
    }

    private fun stopCapture() {
        try { virtualDisplay?.release() } catch (_: Throwable) {}
        virtualDisplay = null
        try { reader?.close() } catch (_: Throwable) {}
        reader = null
        synchronized(this) {
            latestBitmap?.recycle()
            latestBitmap = null
        }
        projection = null
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    override fun onDestroy() {
        sensorManager.unregisterListener(this)
        animator?.cancel()
        overlay?.let { removeOverlay(it) }
        stopCapture()
        frozenBitmap?.recycle()
        frozenBitmap = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CH, "FoldOpenFX", NotificationManager.IMPORTANCE_LOW))
        }
    }
    private fun notification(): Notification {
        return Notification.Builder(this, CH)
            .setContentTitle("FoldOpenFX active")
            .setContentText("Capturing the current screen for fold animation")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
    }

    class FoldOverlay(ctx: Context, private val source: Bitmap) : View(ctx) {
        var progress = 0f
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private val shadow = Paint(Paint.ANTI_ALIAS_FLAG)

        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            val w = width.toFloat()
            val h = height.toFloat()
            if (w <= 0f || h <= 0f || source.isRecycled) return

            val mid = w / 2f
            // The middle opens dramatically, then settles back toward a narrow hinge.
            val eased = (1f - kotlin.math.cos(progress * Math.PI).toFloat()) / 2f
            val gap = w * 0.34f * kotlin.math.sin(eased * Math.PI).toFloat()

            val srcHalf = source.width / 2
            val leftDst = RectF(0f, 0f, mid - gap / 2f, h)
            val rightDst = RectF(mid + gap / 2f, 0f, w, h)

            // Slight perspective squeeze gives the two halves a folding/glass-panel feel.
            val squeeze = 0.96f + 0.04f * kotlin.math.cos(eased * Math.PI).toFloat()
            val leftCenter = leftDst.centerX()
            val rightCenter = rightDst.centerX()
            leftDst.left = leftCenter - leftDst.width() * squeeze / 2f
            leftDst.right = leftCenter + leftDst.width() * squeeze / 2f
            rightDst.left = rightCenter - rightDst.width() * squeeze / 2f
            rightDst.right = rightCenter + rightDst.width() * squeeze / 2f

            c.save()
            c.clipRect(0f, 0f, mid, h)
            c.drawBitmap(source, Rect(0, 0, srcHalf, source.height), leftDst, paint)
            c.restore()

            c.save()
            c.clipRect(mid, 0f, w, h)
            c.drawBitmap(source, Rect(srcHalf, 0, source.width, source.height), rightDst, paint)
            c.restore()

            val shade = 0.45f * kotlin.math.sin(eased * Math.PI).toFloat()
            if (shade > 0f) {
                shadow.shader = LinearGradient(
                    mid - 70f, 0f, mid + 70f, 0f,
                    Color.argb((170f * shade).toInt(), 0, 0, 0),
                    Color.TRANSPARENT,
                    Shader.TileMode.CLAMP
                )
                c.drawRect(mid - 70f, 0f, mid + 70f, h, shadow)
            }
        }
    }
}
