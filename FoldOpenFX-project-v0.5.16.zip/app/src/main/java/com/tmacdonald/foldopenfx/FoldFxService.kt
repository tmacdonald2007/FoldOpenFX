package com.tmacdonald.foldopenfx

import android.animation.ValueAnimator
import android.app.*
import android.app.Activity
import android.content.Intent
import android.content.Context
import android.graphics.*
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.*
import android.widget.Toast
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class FoldFxService : Service(), SensorEventListener {
    companion object {
        const val ACTION_START_CAPTURE = "START_CAPTURE"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "result_data"
        private const val CH = "foldfx"
        private const val NOTIF = 32
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private val frames = AtomicInteger(0)
    private var lastFrameAt = 0L
    private var latestBitmap: Bitmap? = null
    private val bitmapLock = Any()

    private lateinit var sensorManager: SensorManager
    private var hingeSensor: Sensor? = null
    private var lastHinge = Float.NaN
    private var lastMotionAt = 0L
    private var transitionRunning = false

    private var overlay: FoldOverlay? = null
    private var overlayView: FoldTransitionView? = null
    private val main = Handler(Looper.getMainLooper())

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "FoldOpenFX", NotificationManager.IMPORTANCE_LOW))
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        hingeSensor = sensorManager.getDefaultSensor(Sensor.TYPE_HINGE_ANGLE)
        if (hingeSensor != null) {
            sensorManager.registerListener(this, hingeSensor, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_START_CAPTURE) startCapture(intent)
        return START_STICKY
    }

    private fun startCapture(i: Intent) {
        val data = i.getParcelableExtra<Intent>(EXTRA_DATA) ?: return
        startForeground(NOTIF, notification("Fold effect active"))
        stopCaptureOnly()

        thread = HandlerThread("FoldOpenFX-Capture").also { it.start() }
        handler = Handler(thread!!.looper)

        val metrics = android.util.DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val w = metrics.widthPixels
        val h = metrics.heightPixels
        val density = metrics.densityDpi

        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        reader!!.setOnImageAvailableListener({ r -> captureFrame(r) }, handler)

        try {
            projection = (getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager)
                .getMediaProjection(i.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED), data)

            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    main.post { removeOverlay() }
                    stopCaptureOnly()
                }
            }, handler)

            virtualDisplay = projection!!.createVirtualDisplay(
                "FoldOpenFX-VirtualDisplay",
                w, h, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader!!.surface,
                object : VirtualDisplay.Callback() {},
                handler
            )
            main.post {
                Toast.makeText(this, "FoldOpenFX active • frames will feed the hinge effect", Toast.LENGTH_SHORT).show()
            }
        } catch (t: Throwable) {
            main.post { Toast.makeText(this, "Capture error: ${t.javaClass.simpleName}: ${t.message}", Toast.LENGTH_LONG).show() }
        }
    }

    private fun captureFrame(r: ImageReader) {
        try {
            val image = r.acquireLatestImage() ?: return
            try {
                val plane = image.planes[0]
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val paddedWidth = max(image.width, rowStride / pixelStride)
                val buffer = plane.buffer
                buffer.rewind()
                val padded = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
                padded.copyPixelsFromBuffer(buffer)
                val cropped = if (paddedWidth == image.width) padded
                else Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
                synchronized(bitmapLock) {
                    val old = latestBitmap
                    latestBitmap = cropped.copy(Bitmap.Config.ARGB_8888, false)
                    if (cropped !== padded) cropped.recycle()
                    if (padded !== cropped) padded.recycle()
                    old?.recycle()
                }
                val n = frames.incrementAndGet()
                lastFrameAt = System.currentTimeMillis()
                if (n <= 3) {
                    main.post { Toast.makeText(this, "SCREEN FRAME READY ${image.width}x${image.height}", Toast.LENGTH_SHORT).show() }
                }
            } finally {
                image.close()
            }
        } catch (t: Throwable) {
            main.post { Toast.makeText(this, "Frame error: ${t.javaClass.simpleName}", Toast.LENGTH_SHORT).show() }
        }
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_HINGE_ANGLE) return
        val angle = event.values.firstOrNull() ?: return
        if (angle.isNaN()) return
        val previous = lastHinge
        lastHinge = angle
        if (previous.isNaN()) return

        val delta = angle - previous
        if (abs(delta) < 0.8f) return
        val now = SystemClock.uptimeMillis()
        if (now - lastMotionAt < 550) return
        lastMotionAt = now

        val closing = delta < 0f
        main.post { beginTransition(closing, angle) }
    }

    private fun beginTransition(closing: Boolean, angle: Float) {
        if (transitionRunning) return
        val frame = synchronized(bitmapLock) { latestBitmap?.copy(Bitmap.Config.ARGB_8888, false) }
        if (frame == null) {
            Toast.makeText(this, "No screen frame yet — keep FoldOpenFX enabled for a moment", Toast.LENGTH_SHORT).show()
            return
        }
        transitionRunning = true
        showOverlay(frame)

        // Closing: flat -> folded. Opening: folded -> flat.
        val start = if (closing) 0f else 1f
        val end = if (closing) 1f else 0f
        ValueAnimator.ofFloat(start, end).apply {
            duration = 320L
            addUpdateListener { a -> overlayView?.progress = a.animatedValue as Float }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) {
                    transitionRunning = false
                    removeOverlay()
                    frame.recycle()
                }
            })
            start()
        }
    }

    private fun showOverlay(bitmap: Bitmap) {
        removeOverlay()
        overlayView = FoldTransitionView(this, bitmap)
        overlay = FoldOverlay(this, overlayView!!)
        overlay!!.show()
    }

    private fun removeOverlay() {
        overlay?.hide()
        overlay = null
        overlayView = null
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private fun stopCaptureOnly() {
        try { virtualDisplay?.release() } catch (_: Throwable) {}
        virtualDisplay = null
        try { reader?.close() } catch (_: Throwable) {}
        reader = null
        try { projection?.stop() } catch (_: Throwable) {}
        projection = null
        try { thread?.quitSafely() } catch (_: Throwable) {}
        thread = null
        handler = null
    }

    override fun onDestroy() {
        sensorManager.unregisterListener(this)
        removeOverlay()
        stopCaptureOnly()
        synchronized(bitmapLock) {
            latestBitmap?.recycle()
            latestBitmap = null
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun notification(text: String): Notification =
        Notification.Builder(this, CH)
            .setContentTitle("FoldOpenFX")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()

    private class FoldOverlay(
        private val context: Context,
        private val view: View
    ) {
        private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        private var added = false
        private val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )

        fun show() {
            if (added) return
            try { wm.addView(view, params); added = true } catch (_: Throwable) {}
        }

        fun hide() {
            if (!added) return
            try { wm.removeView(view) } catch (_: Throwable) {}
            added = false
        }
    }

    private class FoldTransitionView(
        context: Context,
        private val bitmap: Bitmap
    ) : View(context) {
        var progress: Float = 0f
            set(value) { field = value.coerceIn(0f, 1f); invalidate() }

        private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private val matrix = Matrix()
        private val camera = Camera()
        private val srcLeft = Rect()
        private val srcRight = Rect()
        private val dstLeft = RectF()
        private val dstRight = RectF()

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(Color.BLACK)
            val bw = bitmap.width.toFloat()
            val bh = bitmap.height.toFloat()
            if (bw <= 0f || bh <= 0f) return

            val scale = max(width / bw, height / bh)
            val dw = bw * scale
            val dh = bh * scale
            val ox = (width - dw) / 2f
            val oy = (height - dh) / 2f
            val mid = ox + dw / 2f
            val foldAngle = 78f * progress
            val gap = 2f * progress

            srcLeft.set(0, 0, bitmap.width / 2, bitmap.height)
            srcRight.set(bitmap.width / 2, 0, bitmap.width, bitmap.height)
            dstLeft.set(ox, oy, mid - gap, oy + dh)
            dstRight.set(mid + gap, oy, ox + dw, oy + dh)

            drawPanel(canvas, srcLeft, dstLeft, mid - gap, +foldAngle)
            drawPanel(canvas, srcRight, dstRight, mid + gap, -foldAngle)

            if (progress > 0f) {
                paint.color = Color.argb((70 * progress).toInt(), 0, 0, 0)
                canvas.drawRect(mid - 5f * progress, 0f, mid + 5f * progress, height.toFloat(), paint)
            }
        }

        private fun drawPanel(canvas: Canvas, src: Rect, dst: RectF, pivotX: Float, angle: Float) {
            matrix.reset()
            canvas.save()
            canvas.translate(pivotX, height / 2f)
            camera.save()
            camera.rotateY(angle)
            camera.getMatrix(matrix)
            camera.restore()
            canvas.concat(matrix)
            canvas.translate(-pivotX, -height / 2f)
            canvas.drawBitmap(bitmap, src, dst, paint)
            canvas.restore()
        }
    }
}
