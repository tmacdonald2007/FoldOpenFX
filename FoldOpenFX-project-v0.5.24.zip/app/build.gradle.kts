plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.tmacdonald.foldopenfx"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.tmacdonald.foldopenfx"
        minSdk = 29
        targetSdk = 35
        versionCode = 29
        versionName = "0.5.24"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
