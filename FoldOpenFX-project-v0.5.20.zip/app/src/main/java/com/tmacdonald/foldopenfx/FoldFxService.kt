package com.tmacdonald.foldopenfx

import android.app.*
import android.content.*
import android.graphics.*
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.Toast
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs
import kotlin.math.min

class FoldFxService : Service(), SensorEventListener {
    companion object {
        const val ACTION_START_CAPTURE = "START_CAPTURE"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "result_data"
        private const val CH = "foldfx"
        private const val NOTIF = 31
        private const val HINGE_THRESHOLD = 2.5f
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private val frames = AtomicInteger(0)
    private var lastFrameAt = 0L
    private var lastImageInfo = "none"
    private var captureRunning = false
    private val main = Handler(Looper.getMainLooper())

    private var latestBitmap: Bitmap? = null
    private var bitmapW = 0
    private var bitmapH = 0
    private var lastCopyAt = 0L
    private var compactBuffer: ByteBuffer? = null
    private var compactCapacity = 0
    private val copyLock = Any()

    private lateinit var sensorManager: SensorManager
    private var hingeSensor: Sensor? = null
    private var lastHinge = 180f
    private var moving = false

    private var wm: WindowManager? = null
    private var overlay: FoldOverlayView? = null
    private var overlayAdded = false

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "FoldOpenFX", NotificationManager.IMPORTANCE_LOW))
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        hingeSensor = sensorManager.getDefaultSensor(Sensor.TYPE_HINGE_ANGLE)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_START_CAPTURE) startCapture(intent)
        return START_STICKY
    }

    private fun startCapture(i: Intent) {
        val data = i.getParcelableExtra<Intent>(EXTRA_DATA) ?: return
        startForeground(NOTIF, notification("FoldOpenFX active"))
        if (captureRunning) {
            postStatus("FoldOpenFX already running. frames=${frames.get()}")
            return
        }

        thread = HandlerThread("FoldOpenFX-Capture").also { it.start() }
        handler = Handler(thread!!.looper)

        val metrics = android.util.DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val w = metrics.widthPixels
        val h = metrics.heightPixels
        val density = metrics.densityDpi

        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        reader!!.setOnImageAvailableListener({ r -> onImage(r) }, handler)

        try {
            projection = (getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager)
                .getMediaProjection(i.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED), data)

            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    captureRunning = false
                    postStatus("MediaProjection stopped. frames=${frames.get()}")
                }
            }, handler)

            captureRunning = true
            virtualDisplay = projection!!.createVirtualDisplay(
                "FoldOpenFX-VirtualDisplay",
                w, h, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader!!.surface,
                object : VirtualDisplay.Callback() {
                    override fun onPaused() { postStatus("VirtualDisplay PAUSED") }
                    override fun onResumed() { postStatus("VirtualDisplay RESUMED") }
                    override fun onStopped() { postStatus("VirtualDisplay STOPPED; frames=${frames.get()}") }
                },
                handler
            )
            postStatus("Capture active ${w}x${h}. Hinge animation armed.")
            registerHinge()
        } catch (t: Throwable) {
            postStatus("CAPTURE ERROR: ${t.javaClass.simpleName}: ${t.message}")
        }
    }

    private fun registerHinge() {
        val sensor = hingeSensor
        if (sensor == null) {
            postStatus("HINGE SENSOR NOT FOUND")
            return
        }
        sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_GAME)
        postStatus("HINGE SENSOR ARMED")
    }

    private fun onImage(r: ImageReader) {
        var image: Image? = null
        try {
            image = r.acquireLatestImage() ?: return
            val n = frames.incrementAndGet()
            lastFrameAt = System.currentTimeMillis()
            val plane = image.planes[0]
            lastImageInfo = "${image.width}x${image.height}, planes=${image.planes.size}, rowStride=${plane.rowStride}, pixelStride=${plane.pixelStride}"

            // Keep capture lightweight: refresh the freeze-frame only a few times per second.
            // The animation itself never allocates bitmaps per hinge event.
            val now = System.currentTimeMillis()
            if (now - lastCopyAt >= 250L) {
                lastCopyAt = now
                copyImageToBitmap(image)
            }

            if (n <= 3 || n % 120 == 0) postStatus("FRAMES=$n | $lastImageInfo")
        } catch (t: Throwable) {
            postStatus("IMAGE ERROR: ${t.javaClass.simpleName}: ${t.message}")
        } finally {
            try { image?.close() } catch (_: Throwable) {}
        }
    }

    private fun copyImageToBitmap(image: Image) {
        val plane = image.planes[0]
        val width = image.width
        val height = image.height
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        if (pixelStride < 4 || rowStride < width * pixelStride) return

        synchronized(copyLock) {
            try {
                if (latestBitmap == null || bitmapW != width || bitmapH != height) {
                    latestBitmap?.recycle()
                    latestBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                    bitmapW = width
                    bitmapH = height
                }

                val src = plane.buffer.duplicate().order(ByteOrder.nativeOrder())
                val rowBytes = width * 4
                val needed = rowBytes * height
                if (compactBuffer == null || compactCapacity != needed) {
                    compactBuffer = ByteBuffer.allocateDirect(needed).order(ByteOrder.nativeOrder())
                    compactCapacity = needed
                }
                val compact = compactBuffer!!.apply { clear() }
                val row = ByteArray(rowBytes)
                for (y in 0 until height) {
                    val start = y * rowStride
                    src.position(start)
                    src.get(row, 0, rowBytes)
                    compact.put(row)
                }
                compact.flip()
                latestBitmap!!.copyPixelsFromBuffer(compact)
            } catch (t: Throwable) {
                postStatus("FRAME COPY ERROR: ${t.javaClass.simpleName}: ${t.message}")
            }
        }
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_HINGE_ANGLE) return
        val angle = event.values.firstOrNull() ?: return
        val delta = abs(angle - lastHinge)
        if (delta >= HINGE_THRESHOLD && !moving) {
            moving = true
            main.post { beginAnimation() }
        }
        if (moving) {
            main.post { overlay?.setHingeAngle(angle) }
            if (angle >= 176f || angle <= 4f) {
                // Don't remove immediately; give the physical handoff a short fade.
                val settled = angle
                main.postDelayed({
                    if (abs(lastHinge - settled) < 2f) endAnimation()
                }, 120L)
            }
        }
        lastHinge = angle
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private fun beginAnimation() {
        if (isFinishingOverlay()) return
        val frame = synchronized(copyLock) { latestBitmap }
        if (frame == null) {
            postStatus("HINGE MOVED: waiting for captured frame")
            moving = false
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            postStatus("Overlay permission is required")
            moving = false
            return
        }

        if (overlay == null) overlay = FoldOverlayView(this)
        overlay!!.setBitmap(frame)
        overlay!!.setHingeAngle(lastHinge)
        if (!overlayAdded) {
            wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            try {
                wm!!.addView(overlay, lp)
                overlayAdded = true
            } catch (t: Throwable) {
                postStatus("OVERLAY ERROR: ${t.javaClass.simpleName}: ${t.message}")
                moving = false
                return
            }
        }
        overlay!!.alpha = 1f
        overlay!!.visibility = View.VISIBLE
    }

    private fun endAnimation() {
        if (!overlayAdded) {
            moving = false
            return
        }
        overlay?.animate()?.alpha(0f)?.setDuration(80L)?.withEndAction {
            overlay?.visibility = View.GONE
            moving = false
        }?.start()
    }

    private fun isFinishingOverlay(): Boolean = overlayAdded && overlay?.visibility == View.VISIBLE

    private fun postStatus(s: String) {
        main.post { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }
    }

    private fun notification(text: String): Notification =
        Notification.Builder(this, CH)
            .setContentTitle("FoldOpenFX")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()

    private fun stopCapture() {
        captureRunning = false
        try { sensorManager.unregisterListener(this) } catch (_: Throwable) {}
        try { if (overlayAdded) wm?.removeViewImmediate(overlay) } catch (_: Throwable) {}
        overlayAdded = false
        overlay = null
        try { virtualDisplay?.release() } catch (_: Throwable) {}
        virtualDisplay = null
        try { reader?.close() } catch (_: Throwable) {}
        reader = null
        try { projection?.stop() } catch (_: Throwable) {}
        projection = null
        try { thread?.quitSafely() } catch (_: Throwable) {}
        thread = null
        handler = null
        synchronized(copyLock) {
            try { latestBitmap?.recycle() } catch (_: Throwable) {}
            latestBitmap = null
            compactBuffer = null
            compactCapacity = 0
        }
    }

    override fun onDestroy() {
        stopCapture()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private class FoldOverlayView(context: Context) : View(context) {
        private var bitmap: Bitmap? = null
        private var hinge = 180f
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { isDither = true }
        private val camera = Camera()
        private val matrix = Matrix()

        fun setBitmap(b: Bitmap) {
            bitmap = b
            invalidate()
        }

        fun setHingeAngle(a: Float) {
            hinge = a.coerceIn(0f, 180f)
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val b = bitmap ?: return
            if (b.width < 2 || b.height < 2) return

            val sx = width.toFloat() / b.width.toFloat()
            val sy = height.toFloat() / b.height.toFloat()
            val scale = min(sx, sy)
            val drawW = b.width * scale
            val drawH = b.height * scale
            val left = (width - drawW) / 2f
            val top = (height - drawH) / 2f

            val half = b.width / 2
            val openFactor = (hinge / 180f).coerceIn(0f, 1f)
            val fold = 1f - openFactor
            val depth = fold * min(width, height) * 0.055f
            val lift = fold * min(width, height) * 0.025f

            // Android's Camera Y rotation sign is opposite the physical hinge fold
            // direction for the two halves. Reverse the signs so the panels
            // move toward the hinge while closing and away from it while opening.
            drawPanel(canvas, b, 0, half, left, top, scale, (fold * 72f), -depth, -lift)
            drawPanel(canvas, b, half, b.width, left, top, scale, -(fold * 72f), depth, -lift)
        }

        private fun drawPanel(
            canvas: Canvas,
            b: Bitmap,
            srcLeft: Int,
            srcRight: Int,
            dstLeft: Float,
            dstTop: Float,
            scale: Float,
            rotation: Float,
            z: Float,
            yShift: Float
        ) {
            val src = Rect(srcLeft, 0, srcRight, b.height)
            val centerX = dstLeft + ((srcLeft + srcRight) / 2f) * scale
            val centerY = dstTop + b.height * scale / 2f
            val dst = RectF(
                dstLeft + srcLeft * scale,
                dstTop + yShift + 0f,
                dstLeft + srcRight * scale,
                dstTop + yShift + b.height * scale
            )

            camera.save()
            camera.rotateY(rotation)
            camera.getMatrix(matrix)
            camera.restore()
            matrix.preTranslate(-centerX, -centerY)
            matrix.postTranslate(centerX + z, centerY)

            canvas.save()
            canvas.concat(matrix)
            canvas.drawBitmap(b, src, dst, paint)
            canvas.restore()
        }
    }
}
