package com.tmacdonald.foldopenfx

import android.app.*
import android.content.*
import android.graphics.*
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.provider.Settings
import android.view.*
import android.view.Choreographer
import android.widget.Toast
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs
import kotlin.math.min

class FoldFxService : Service(), SensorEventListener {
    companion object {
        const val ACTION_START_CAPTURE = "START_CAPTURE"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "result_data"
        private const val CH = "foldfx"
        private const val NOTIF = 31
        private const val HINGE_THRESHOLD = 2.5f
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private val frames = AtomicInteger(0)
    private var lastFrameAt = 0L
    private var lastImageInfo = "none"
    private var captureRunning = false
    private val main = Handler(Looper.getMainLooper())

    private var latestBitmap: Bitmap? = null
    private var bitmapW = 0
    private var bitmapH = 0
    private var lastCopyAt = 0L
    private var compactBuffer: ByteBuffer? = null
    private var compactCapacity = 0
    private val copyLock = Any()

    private lateinit var sensorManager: SensorManager
    private var hingeSensor: Sensor? = null
    private var lastHinge = 180f
    private var moving = false

    private var wm: WindowManager? = null
    private var overlay: FoldOverlayView? = null
    private var overlayAdded = false
    private var animationBitmap: Bitmap? = null
    private var targetHinge = 180f
    private var renderedHinge = 180f
    private var frameCallbackPosted = false
    private val choreographer = Choreographer.getInstance()

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "FoldOpenFX", NotificationManager.IMPORTANCE_LOW))
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        hingeSensor = sensorManager.getDefaultSensor(Sensor.TYPE_HINGE_ANGLE)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_START_CAPTURE) startCapture(intent)
        return START_STICKY
    }

    private fun startCapture(i: Intent) {
        val data = i.getParcelableExtra<Intent>(EXTRA_DATA) ?: return
        startForeground(NOTIF, notification("FoldOpenFX active"))
        if (captureRunning) {
            postStatus("FoldOpenFX already running. frames=${frames.get()}")
            return
        }

        thread = HandlerThread("FoldOpenFX-Capture").also { it.start() }
        handler = Handler(thread!!.looper)

        val metrics = android.util.DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val w = metrics.widthPixels
        val h = metrics.heightPixels
        val density = metrics.densityDpi

        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        reader!!.setOnImageAvailableListener({ r -> onImage(r) }, handler)

        try {
            projection = (getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager)
                .getMediaProjection(i.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED), data)

            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    captureRunning = false
                    postStatus("MediaProjection stopped. frames=${frames.get()}")
                }
            }, handler)

            captureRunning = true
            virtualDisplay = projection!!.createVirtualDisplay(
                "FoldOpenFX-VirtualDisplay",
                w, h, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader!!.surface,
                object : VirtualDisplay.Callback() {
                    override fun onPaused() { postStatus("VirtualDisplay PAUSED") }
                    override fun onResumed() { postStatus("VirtualDisplay RESUMED") }
                    override fun onStopped() { postStatus("VirtualDisplay STOPPED; frames=${frames.get()}") }
                },
                handler
            )
            postStatus("Capture active ${w}x${h}. Hinge animation armed.")
            registerHinge()
        } catch (t: Throwable) {
            postStatus("CAPTURE ERROR: ${t.javaClass.simpleName}: ${t.message}")
        }
    }

    private fun registerHinge() {
        val sensor = hingeSensor
        if (sensor == null) {
            postStatus("HINGE SENSOR NOT FOUND")
            return
        }
        sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_GAME)
        postStatus("HINGE SENSOR ARMED")
    }

    private fun onImage(r: ImageReader) {
        var image: Image? = null
        try {
            image = r.acquireLatestImage() ?: return
            val n = frames.incrementAndGet()
            lastFrameAt = System.currentTimeMillis()
            val plane = image.planes[0]
            lastImageInfo = "${image.width}x${image.height}, planes=${image.planes.size}, rowStride=${plane.rowStride}, pixelStride=${plane.pixelStride}"

            // Keep capture lightweight: refresh the freeze-frame only a few times per second.
            // The animation itself never allocates bitmaps per hinge event.
            val now = System.currentTimeMillis()
            if (now - lastCopyAt >= 250L) {
                lastCopyAt = now
                copyImageToBitmap(image)
            }

            if (n <= 3 || n % 120 == 0) postStatus("FRAMES=$n | $lastImageInfo")
        } catch (t: Throwable) {
            postStatus("IMAGE ERROR: ${t.javaClass.simpleName}: ${t.message}")
        } finally {
            try { image?.close() } catch (_: Throwable) {}
        }
    }

    private fun copyImageToBitmap(image: Image) {
        val plane = image.planes[0]
        val width = image.width
        val height = image.height
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        if (pixelStride < 4 || rowStride < width * pixelStride) return

        synchronized(copyLock) {
            try {
                if (latestBitmap == null || bitmapW != width || bitmapH != height) {
                    latestBitmap?.recycle()
                    latestBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                    bitmapW = width
                    bitmapH = height
                }

                val src = plane.buffer.duplicate().order(ByteOrder.nativeOrder())
                val rowBytes = width * 4
                val needed = rowBytes * height
                if (compactBuffer == null || compactCapacity != needed) {
                    compactBuffer = ByteBuffer.allocateDirect(needed).order(ByteOrder.nativeOrder())
                    compactCapacity = needed
                }
                val compact = compactBuffer!!.apply { clear() }
                val row = ByteArray(rowBytes)
                for (y in 0 until height) {
                    val start = y * rowStride
                    src.position(start)
                    src.get(row, 0, rowBytes)
                    compact.put(row)
                }
                compact.flip()
                latestBitmap!!.copyPixelsFromBuffer(compact)
            } catch (t: Throwable) {
                postStatus("FRAME COPY ERROR: ${t.javaClass.simpleName}: ${t.message}")
            }
        }
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_HINGE_ANGLE) return
        val angle = event.values.firstOrNull() ?: return
        val delta = abs(angle - lastHinge)
        if (delta >= HINGE_THRESHOLD && !moving) {
            moving = true
            main.post { beginAnimation() }
        }
        if (moving) {
            targetHinge = angle.coerceIn(0f, 180f)
            if (!frameCallbackPosted) {
                frameCallbackPosted = true
                main.post { startFrameLoop() }
            }
            if (angle >= 176f || angle <= 4f) {
                // Don't remove immediately; give the physical handoff a short fade.
                val settled = angle
                main.postDelayed({
                    if (abs(lastHinge - settled) < 2f) endAnimation()
                }, 120L)
            }
        }
        lastHinge = angle
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private fun beginAnimation() {
        if (isFinishingOverlay()) return
        val frame = synchronized(copyLock) {
            latestBitmap?.copy(Bitmap.Config.ARGB_8888, false)
        }
        if (frame == null) {
            postStatus("HINGE MOVED: waiting for captured frame")
            moving = false
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            postStatus("Overlay permission is required")
            moving = false
            return
        }

        if (overlay == null) overlay = FoldOverlayView(this)
        animationBitmap?.recycle()
        animationBitmap = frame
        renderedHinge = lastHinge
        targetHinge = lastHinge
        overlay!!.setBitmap(animationBitmap!!)
        overlay!!.setHingeAngle(renderedHinge)
        if (!overlayAdded) {
            wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            try {
                wm!!.addView(overlay, lp)
                overlayAdded = true
            } catch (t: Throwable) {
                postStatus("OVERLAY ERROR: ${t.javaClass.simpleName}: ${t.message}")
                moving = false
                return
            }
        }
        overlay!!.alpha = 1f
        overlay!!.visibility = View.VISIBLE
    }

    private fun endAnimation() {
        if (!overlayAdded) {
            moving = false
            frameCallbackPosted = false
            return
        }
        overlay?.animate()?.alpha(0f)?.setDuration(70L)?.withEndAction {
            overlay?.visibility = View.GONE
            moving = false
            frameCallbackPosted = false
            animationBitmap?.recycle()
            animationBitmap = null
        }?.start()
    }

    private fun startFrameLoop() {
        choreographer.postFrameCallback(object : Choreographer.FrameCallback {
            override fun doFrame(frameTimeNanos: Long) {
                if (!moving || !overlayAdded) {
                    frameCallbackPosted = false
                    return
                }
                val diff = targetHinge - renderedHinge
                renderedHinge += diff * 0.42f
                if (abs(diff) < 0.15f) renderedHinge = targetHinge
                overlay?.setHingeAngle(renderedHinge)
                choreographer.postFrameCallback(this)
            }
        })
    }

    private fun isFinishingOverlay(): Boolean = overlayAdded && overlay?.visibility == View.VISIBLE

    private fun postStatus(s: String) {
        main.post { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }
    }

    private fun notification(text: String): Notification =
        Notification.Builder(this, CH)
            .setContentTitle("FoldOpenFX")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()

    private fun stopCapture() {
        captureRunning = false
        try { sensorManager.unregisterListener(this) } catch (_: Throwable) {}
        try { if (overlayAdded) wm?.removeViewImmediate(overlay) } catch (_: Throwable) {}
        overlayAdded = false
        overlay = null
        animationBitmap?.recycle()
        animationBitmap = null
        frameCallbackPosted = false
        try { virtualDisplay?.release() } catch (_: Throwable) {}
        virtualDisplay = null
        try { reader?.close() } catch (_: Throwable) {}
        reader = null
        try { projection?.stop() } catch (_: Throwable) {}
        projection = null
        try { thread?.quitSafely() } catch (_: Throwable) {}
        thread = null
        handler = null
        synchronized(copyLock) {
            try { latestBitmap?.recycle() } catch (_: Throwable) {}
            latestBitmap = null
            compactBuffer = null
            compactCapacity = 0
        }
    }

    override fun onDestroy() {
        stopCapture()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private class FoldOverlayView(context: Context) : View(context) {
        private var bitmap: Bitmap? = null
        private var hinge = 180f
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            isDither = true
        }
        private val matrix = Matrix()
        private val camera = Camera()

        fun setBitmap(b: Bitmap) {
            bitmap = b
            invalidate()
        }

        fun setHingeAngle(a: Float) {
            hinge = a.coerceIn(0f, 180f)
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val b = bitmap ?: return
            if (b.width < 2 || b.height < 2) return

            val sx = width.toFloat() / b.width.toFloat()
            val sy = height.toFloat() / b.height.toFloat()
            val scale = min(sx, sy)
            val drawW = b.width * scale
            val drawH = b.height * scale
            val left = (width - drawW) / 2f
            val top = (height - drawH) / 2f
            val half = b.width / 2

            // When Android hands the overlay to the narrow cover display, mirror
            // the cover-facing half of the same captured inner-screen image. This
            // is the key handoff that makes the transition read as one UI moving
            // from the inner screen to the next screen rather than a page turning.
            val innerAspect = maxOf(b.width.toFloat() / b.height.toFloat(), b.height.toFloat() / b.width.toFloat())
            val viewAspect = maxOf(width.toFloat() / height.toFloat(), height.toFloat() / width.toFloat())
            val coverMode = viewAspect > innerAspect * 1.45f
            if (coverMode && fold > 0.03f) {
                val coverSrc = Rect(half, 0, b.width, b.height)
                canvas.drawBitmap(b, coverSrc, RectF(0f, 0f, width.toFloat(), height.toFloat()), paint)
                val dim = ((1f - fold) * 0.20f).coerceIn(0f, 0.20f)
                if (dim > 0.01f) {
                    paint.color = Color.BLACK
                    paint.alpha = (dim * 255f).toInt()
                    canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
                    paint.color = Color.WHITE
                    paint.alpha = 255
                }
                return
            }

            // The Duo-like illusion is a shared image, not two independent pages.
            // One panel stays visually anchored while the cover half folds away.
            // This keeps icons/content aligned in space as the hardware changes pose.
            val open = (hinge / 180f).coerceIn(0f, 1f)
            val fold = 1f - open

            if (fold <= 0.01f) {
                canvas.drawBitmap(b, null, RectF(left, top, left + drawW, top + drawH), paint)
                return
            }

            // Left/rear half remains the fixed reference plane.
            val leftDst = RectF(left, top, left + half * scale, top + drawH)
            canvas.drawBitmap(b, Rect(0, 0, half, b.height), leftDst, paint)

            // Right/cover half rotates out from the hinge. Its source pixels remain
            // tied to the shared image so the two halves read as one continuous UI.
            val rightDst = RectF(left + half * scale, top, left + drawW, top + drawH)
            val pivotX = rightDst.left
            val pivotY = rightDst.centerY()
            val rotation = -fold * 90f

            camera.save()
            camera.rotateY(rotation)
            camera.getMatrix(matrix)
            camera.restore()
            matrix.preTranslate(-pivotX, -pivotY)
            matrix.postTranslate(pivotX, pivotY)

            canvas.save()
            canvas.concat(matrix)
            canvas.drawBitmap(b, Rect(half, 0, b.width, b.height), rightDst, paint)
            canvas.restore()

            // Duo-style optical cue: darken/soften the moving panel as it turns away.
            val cue = (fold * 0.32f).coerceIn(0f, 0.32f)
            if (cue > 0.01f) {
                paint.color = Color.BLACK
                paint.alpha = (cue * 255f).toInt()
                canvas.drawRect(left, top, left + drawW, top + drawH, paint)
                paint.color = Color.WHITE
                paint.alpha = 255
            }
        }
    }
}
