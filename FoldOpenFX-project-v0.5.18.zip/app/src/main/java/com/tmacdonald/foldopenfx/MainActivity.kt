package com.tmacdonald.foldopenfx

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.net.Uri
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    companion object { const val REQ_CAPTURE = 4101 }

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        status.text = "Ready. Stable capture test: VirtualDisplay should continuously receive frames."
    }

    private fun buildUi() {
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad,pad,pad,pad)
        }
        val title = TextView(this).apply {
            text = "UNLOCKED FOLD TRANSITION BUILD v0.5.18"
            textSize = 20f
        }
        status = TextView(this).apply { textSize = 16f; setPadding(0,pad,0,pad) }
        val overlay = Button(this).apply {
            text = "1. Grant overlay permission"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        }
        val enable = Button(this).apply {
            text = "2. Enable capture diagnostic"
            setOnClickListener { requestCapture() }
        }
        val stop = Button(this).apply {
            text = "Stop diagnostic"
            setOnClickListener {
                stopService(Intent(this@MainActivity, FoldFxService::class.java))
                status.text = "Stopped."
            }
        }
        root.addView(title); root.addView(status); root.addView(overlay); root.addView(enable); root.addView(stop)
        setContentView(root)
    }

    private fun requestCapture() {
        val pm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(pm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    override fun onActivityResult(requestCode:Int, resultCode:Int, data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if (requestCode != REQ_CAPTURE || data == null) {
            Toast.makeText(this, "Capture permission not granted.", Toast.LENGTH_LONG).show()
            return
        }
        val i = Intent(this, FoldFxService::class.java).apply {
            action = FoldFxService.ACTION_START_CAPTURE
            putExtra(FoldFxService.EXTRA_RESULT_CODE, resultCode)
            putExtra(FoldFxService.EXTRA_DATA, data)
        }
        startForegroundService(i)
        status.text = "Capture approved; starting VirtualDisplay diagnostic..."
    }
}
