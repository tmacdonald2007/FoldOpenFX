package com.tmacdonald2007.foldopenfx

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class FoldFxService : Service(), SensorEventListener {

    private lateinit var wm: WindowManager
    private lateinit var overlay: FoldFxOverlay
    private lateinit var sensors: SensorManager
    private var hinge: Sensor? = null

    override fun onCreate() {
        super.onCreate()

        createChannel()

        val n = notification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(
                42, n,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(42, n)
        }

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        sensors = getSystemService(SENSOR_SERVICE) as SensorManager
        hinge = sensors.getDefaultSensor(Sensor.TYPE_HINGE_ANGLE)

        overlay = FoldFxOverlay(this)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            android.graphics.PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }

        if (Settings.canDrawOverlays(this)) {
            runCatching { wm.addView(overlay, params) }
                .onFailure { overlay.errorMessage = "OVERLAY ERROR" }
        } else {
            overlay.errorMessage = "OVERLAY PERMISSION OFF"
        }

        hinge?.let {
            sensors.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        } ?: run {
            overlay.errorMessage = "NO HINGE SENSOR"
        }
    }

    override fun onDestroy() {
        if (::sensors.isInitialized) sensors.unregisterListener(this)
        if (::overlay.isInitialized) runCatching { wm.removeView(overlay) }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type == Sensor.TYPE_HINGE_ANGLE) {
            overlay.setHinge(event.values.firstOrNull() ?: 180f)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val c = NotificationChannel(
                "foldopenfx", "FoldOpenFX", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(c)
        }
    }

    private fun notification(): Notification {
        val b = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, "foldopenfx")
        else
            Notification.Builder(this)

        return b.setContentTitle("FoldOpenFX active")
            .setContentText("Full-screen fold transition is running")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
    }
}

private class FoldFxOverlay(context: Context) : View(context) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shade = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    private var angle = 180f
    private var previousAngle = 180f
    private var previousTime = 0L
    private var speed = 0f
    private var lastMovement = 0L
    var errorMessage = ""

    fun setHinge(value: Float) {
        val now = SystemClock.elapsedRealtime()
        val next = value.coerceIn(0f, 180f)

        if (previousTime != 0L) {
            val dt = max(1L, now - previousTime)
            val delta = next - previousAngle
            val velocity = abs(delta) * 1000f / dt

            if (abs(delta) > 0.08f || velocity > 5f) {
                speed = min(1f, max(abs(delta) / 1.5f, velocity / 120f))
                lastMovement = now
            } else {
                speed *= 0.88f
            }
        }

        angle = next
        previousAngle = next
        previousTime = now
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val now = SystemClock.elapsedRealtime()
        val moving = now - lastMovement < 170L || speed > 0.025f

        if (!moving) return

        val center = width / 2f
        val fold = 1f - (angle / 180f).coerceIn(0f, 1f)

        /*
         * The animation intentionally covers most of the display.
         * At the beginning of a fold the two panels are narrow at the
         * center; as the hinge moves they expand toward the edges.
         */
        val progress = (0.10f + fold * 0.90f).coerceIn(0f, 1f)
        val halfScreen = width / 2f
        val openingWidth = halfScreen * (0.10f + progress * 0.90f)

        val fade = min(1f, speed * 1.35f + 0.18f)
        val edge = 18f + (1f - progress) * 30f

        drawPanel(canvas, center, -1f, openingWidth, edge, fade)
        drawPanel(canvas, center, 1f, openingWidth, edge, fade)

        // Deep crease shadow.
        val shadowAlpha = (145f * fade * (1f - progress * 0.55f))
            .toInt().coerceIn(0, 180)
        paint.color = Color.argb(shadowAlpha, 0, 0, 0)
        canvas.drawRect(
            center - 7f, 0f, center + 7f, height.toFloat(), paint
        )

        // Thin specular crease.
        paint.color = Color.argb(
            (190f * fade * (0.35f + (1f - progress) * 0.65f))
                .toInt().coerceIn(0, 230),
            255, 255, 255
        )
        canvas.drawRect(
            center - 1.5f, 0f, center + 1.5f, height.toFloat(), paint
        )

        // Dark edge at the far outside of each moving panel.
        val edgeAlpha = (105f * fade * (1f - progress * 0.35f))
            .toInt().coerceIn(0, 130)
        paint.color = Color.argb(edgeAlpha, 0, 0, 0)
        canvas.drawRect(
            center - openingWidth - 5f, 0f,
            center - openingWidth, height.toFloat(), paint
        )
        canvas.drawRect(
            center + openingWidth, 0f,
            center + openingWidth + 5f, height.toFloat(), paint
        )

        postInvalidateDelayed(16L)
        speed *= 0.985f
    }

    private fun drawPanel(
        canvas: Canvas,
        center: Float,
        side: Float,
        openingWidth: Float,
        edge: Float,
        fade: Float
    ) {
        val inner = center
        val outer = center + side * openingWidth

        val alpha = (105f * fade).toInt().coerceIn(0, 120)

        shade.shader = LinearGradient(
            if (side < 0) outer else inner,
            0f,
            if (side < 0) inner else outer,
            0f,
            Color.argb(0, 255, 255, 255),
            Color.argb(alpha, 250, 250, 255),
            Color.argb((alpha * 0.25f).toInt(), 255, 255, 255),
            Shader.TileMode.CLAMP
        )

        canvas.drawRect(
            min(inner, outer), 0f,
            max(inner, outer), height.toFloat(),
            shade
        )
        shade.shader = null

        // A subtle 3-D folded edge.
        val depth = min(42f, openingWidth * 0.13f)
        path.reset()

        if (side < 0f) {
            path.moveTo(inner, 0f)
            path.lineTo(outer, depth)
            path.lineTo(outer, height - depth)
            path.lineTo(inner, height.toFloat())
        } else {
            path.moveTo(inner, 0f)
            path.lineTo(outer, -depth)
            path.lineTo(outer, height + depth)
            path.lineTo(inner, height.toFloat())
        }
        path.close()

        paint.color = Color.argb(
            (42f * fade).toInt().coerceIn(0, 55),
            255, 255, 255
        )
        canvas.drawPath(path, paint)

        // Narrow frosted edge where each panel meets the moving screen.
        val innerGlow = edge
        shade.shader = LinearGradient(
            if (side < 0) inner - innerGlow else inner,
            0f,
            if (side < 0) inner else inner + innerGlow,
            0f,
            Color.argb(0,255,255,255),
            Color.argb((75f*fade).toInt().coerceIn(0,90),255,255,255),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(
            inner - innerGlow, 0f,
            inner + innerGlow, height.toFloat(),
            shade
        )
        shade.shader = null
    }
}
