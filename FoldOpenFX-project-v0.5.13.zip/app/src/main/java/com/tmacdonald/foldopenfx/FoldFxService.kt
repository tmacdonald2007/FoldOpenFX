package com.tmacdonald.foldopenfx

import android.app.*
import android.content.*
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.app.Activity
import android.view.WindowManager
import android.widget.Toast
import java.util.concurrent.atomic.AtomicInteger

class FoldFxService : Service() {
    companion object {
        const val ACTION_START_CAPTURE = "START_CAPTURE"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "result_data"
        private const val CH = "foldfx_diag"
        private const val NOTIF = 31
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private val frames = AtomicInteger(0)
    private var lastFrameAt = 0L
    private var lastImageInfo = "none"
    private val main = Handler(Looper.getMainLooper())

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "FoldOpenFX diagnostic", NotificationManager.IMPORTANCE_LOW))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_START_CAPTURE) {
            startCapture(intent)
        }
        return START_STICKY
    }

    private fun startCapture(i: Intent) {
        val data = i.getParcelableExtra<Intent>(EXTRA_DATA) ?: return
        startForeground(NOTIF, notification("Capture diagnostic running"))
        stopCapture()

        thread = HandlerThread("FoldOpenFX-Capture").also { it.start() }
        handler = Handler(thread!!.looper)

        val metrics = android.util.DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val w = metrics.widthPixels
        val h = metrics.heightPixels
        val density = metrics.densityDpi

        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        reader!!.setOnImageAvailableListener({ r ->
            try {
                val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
                val n = frames.incrementAndGet()
                lastFrameAt = System.currentTimeMillis()
                lastImageInfo = "${image.width}x${image.height}, planes=${image.planes.size}, rowStride=${image.planes[0].rowStride}, pixelStride=${image.planes[0].pixelStride}"
                image.close()
                if (n <= 3 || n % 30 == 0) postStatus("FRAMES=$n | $lastImageInfo")
            } catch (t: Throwable) {
                postStatus("IMAGE ERROR: ${t.javaClass.simpleName}: ${t.message}")
            }
        }, handler)

        try {
            projection = (getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager)
                .getMediaProjection(i.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED), data)

            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    postStatus("MediaProjection stopped by system/user. frames=${frames.get()}")
                    stopCapture()
                }
            }, handler)

            virtualDisplay = projection!!.createVirtualDisplay(
                "FoldOpenFX-VirtualDisplay-Diagnostic",
                w, h, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader!!.surface,
                object : VirtualDisplay.Callback() {
                    override fun onPaused() { postStatus("VirtualDisplay: PAUSED") }
                    override fun onResumed() { postStatus("VirtualDisplay: RESUMED") }
                    override fun onStopped() { postStatus("VirtualDisplay: STOPPED; frames=${frames.get()}") }
                },
                handler
            )
            postStatus("VirtualDisplay CREATED ${w}x${h} density=$density. Waiting for frames...")
            main.postDelayed({ report() }, 3000)
            main.postDelayed({ report() }, 8000)
        } catch (t: Throwable) {
            postStatus("VIRTUAL DISPLAY ERROR: ${t.javaClass.simpleName}: ${t.message}")
        }
    }

    private fun report() {
        val f = frames.get()
        val age = if (lastFrameAt == 0L) "never" else "${System.currentTimeMillis()-lastFrameAt}ms ago"
        val msg = "REPORT: frames=$f last=$age | $lastImageInfo"
        postStatus(msg)
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    private fun postStatus(s: String) {
        main.post { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }
    }

    private fun notification(text: String): Notification =
        Notification.Builder(this, CH)
            .setContentTitle("FoldOpenFX")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()

    private fun stopCapture() {
        try { virtualDisplay?.release() } catch (_:Throwable) {}
        virtualDisplay = null
        try { reader?.close() } catch (_:Throwable) {}
        reader = null
        try { projection?.stop() } catch (_:Throwable) {}
        projection = null
        try { thread?.quitSafely() } catch (_:Throwable) {}
        thread = null
        handler = null
    }

    override fun onDestroy() {
        stopCapture()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) : IBinder? = null
}
