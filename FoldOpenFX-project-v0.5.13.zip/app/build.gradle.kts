plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.tmacdonald.foldopenfx"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.tmacdonald.foldopenfx"
        minSdk = 29
        targetSdk = 35
        versionCode = 19
        versionName = "0.5.13"
    }
}
