package com.tmacdonald.foldopenfx

import android.app.*
import android.content.*
import android.graphics.*
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.provider.Settings
import android.view.*
import android.view.Choreographer
import android.widget.Toast
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs
import kotlin.math.min

class FoldFxService : Service(), SensorEventListener {
    companion object {
        const val ACTION_START_CAPTURE = "START_CAPTURE"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "result_data"
        private const val CH = "foldfx"
        private const val NOTIF = 31
        private const val HINGE_THRESHOLD = 2.5f
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private val frames = AtomicInteger(0)
    private var lastFrameAt = 0L
    private var lastImageInfo = "none"
    private var captureRunning = false
    private val main = Handler(Looper.getMainLooper())

    private var latestBitmap: Bitmap? = null
    private var bitmapW = 0
    private var bitmapH = 0
    private var lastCopyAt = 0L
    private var compactBuffer: ByteBuffer? = null
    private var compactCapacity = 0
    private var rowBuffer: ByteArray? = null
    private val copyLock = Any()

    private lateinit var sensorManager: SensorManager
    private var hingeSensor: Sensor? = null
    private var lastHinge = 180f
    private var moving = false

    private var wm: WindowManager? = null
    private var overlay: FoldOverlayView? = null
    private var overlayAdded = false
    private var animationBitmap: Bitmap? = null
    private var targetHinge = 180f
    private var renderedHinge = 180f
    private var frameCallbackPosted = false
    private var animationStartedAt = 0L
    private val choreographer = Choreographer.getInstance()

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "FoldOpenFX", NotificationManager.IMPORTANCE_LOW))
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        hingeSensor = sensorManager.getDefaultSensor(Sensor.TYPE_HINGE_ANGLE)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_START_CAPTURE) startCapture(intent)
        return START_STICKY
    }

    private fun startCapture(i: Intent) {
        val data = i.getParcelableExtra<Intent>(EXTRA_DATA) ?: return
        startForeground(NOTIF, notification("FoldOpenFX active"))
        if (captureRunning) {
            postStatus("FoldOpenFX already running. frames=${frames.get()}")
            return
        }

        thread = HandlerThread("FoldOpenFX-Capture").also { it.start() }
        handler = Handler(thread!!.looper)

        val metrics = android.util.DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val w = metrics.widthPixels
        val h = metrics.heightPixels
        val density = metrics.densityDpi

        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        reader!!.setOnImageAvailableListener({ r -> onImage(r) }, handler)

        try {
            projection = (getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager)
                .getMediaProjection(i.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED), data)

            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    captureRunning = false
                    postStatus("MediaProjection stopped. frames=${frames.get()}")
                }
            }, handler)

            captureRunning = true
            virtualDisplay = projection!!.createVirtualDisplay(
                "FoldOpenFX-VirtualDisplay",
                w, h, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader!!.surface,
                object : VirtualDisplay.Callback() {
                    override fun onPaused() { postStatus("VirtualDisplay PAUSED") }
                    override fun onResumed() { postStatus("VirtualDisplay RESUMED") }
                    override fun onStopped() { postStatus("VirtualDisplay STOPPED; frames=${frames.get()}") }
                },
                handler
            )
            postStatus("Capture active ${w}x${h}. Hinge animation armed.")
            registerHinge()
        } catch (t: Throwable) {
            postStatus("CAPTURE ERROR: ${t.javaClass.simpleName}: ${t.message}")
        }
    }

    private fun registerHinge() {
        val sensor = hingeSensor
        if (sensor == null) {
            postStatus("HINGE SENSOR NOT FOUND")
            return
        }
        sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_GAME)
        postStatus("HINGE SENSOR ARMED")
    }

    private fun onImage(r: ImageReader) {
        var image: Image? = null
        try {
            image = r.acquireLatestImage() ?: return
            val n = frames.incrementAndGet()
            lastFrameAt = System.currentTimeMillis()
            val plane = image.planes[0]
            lastImageInfo = "${image.width}x${image.height}, planes=${image.planes.size}, rowStride=${plane.rowStride}, pixelStride=${plane.pixelStride}"

            // Keep capture lightweight: refresh the freeze-frame only a few times per second.
            // The animation itself never allocates bitmaps per hinge event.
            val now = System.currentTimeMillis()
            if (!moving && now - lastCopyAt >= 400L) {
                lastCopyAt = now
                copyImageToBitmap(image)
            }

            if (n <= 3 || n % 120 == 0) postStatus("FRAMES=$n | $lastImageInfo")
        } catch (t: Throwable) {
            postStatus("IMAGE ERROR: ${t.javaClass.simpleName}: ${t.message}")
        } finally {
            try { image?.close() } catch (_: Throwable) {}
        }
    }

    private fun copyImageToBitmap(image: Image) {
        val plane = image.planes[0]
        val width = image.width
        val height = image.height
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        if (pixelStride < 4 || rowStride < width * pixelStride) return

        synchronized(copyLock) {
            try {
                if (latestBitmap == null || bitmapW != width || bitmapH != height) {
                    latestBitmap?.recycle()
                    latestBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                    bitmapW = width
                    bitmapH = height
                }

                val src = plane.buffer.duplicate().order(ByteOrder.nativeOrder())
                val rowBytes = width * 4
                val needed = rowBytes * height
                if (compactBuffer == null || compactCapacity != needed) {
                    compactBuffer = ByteBuffer.allocateDirect(needed).order(ByteOrder.nativeOrder())
                    compactCapacity = needed
                }
                val compact = compactBuffer!!.apply { clear() }
                if (rowBuffer == null || rowBuffer!!.size != rowBytes) {
                    rowBuffer = ByteArray(rowBytes)
                }
                val row = rowBuffer!!
                for (y in 0 until height) {
                    val start = y * rowStride
                    src.position(start)
                    src.get(row, 0, rowBytes)
                    compact.put(row)
                }
                compact.flip()
                latestBitmap!!.copyPixelsFromBuffer(compact)
            } catch (t: Throwable) {
                postStatus("FRAME COPY ERROR: ${t.javaClass.simpleName}: ${t.message}")
            }
        }
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_HINGE_ANGLE) return
        val angle = event.values.firstOrNull() ?: return
        val delta = abs(angle - lastHinge)
        if (delta >= HINGE_THRESHOLD && !moving) {
            moving = true
            animationStartedAt = SystemClock.uptimeMillis()
            main.post { beginAnimation() }
        }
        if (moving) {
            targetHinge = angle.coerceIn(0f, 180f)
            if (!frameCallbackPosted) {
                frameCallbackPosted = true
                main.post { startFrameLoop() }
            }
            if (angle >= 176f || angle <= 4f) {
                // End promptly at the physical endpoint. A cover-display switch can
                // stop hinge callbacks temporarily, so do not wait indefinitely.
                val settled = angle
                main.postDelayed({
                    if (moving && (abs(lastHinge - settled) < 2f ||
                        SystemClock.uptimeMillis() - animationStartedAt > 1400L)) {
                        endAnimation()
                    }
                }, 140L)
            }

            // Absolute safety valve: the visual handoff should never remain stuck
            // over the cover display if Android changes displays mid-transition.
            if (moving && SystemClock.uptimeMillis() - animationStartedAt > 1800L) {
                main.post { endAnimation() }
            }
        }
        lastHinge = angle
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private fun beginAnimation() {
        if (isFinishingOverlay()) return
        // Never animate the full 2448x1848 capture bitmap. A full-size copy plus
        // Camera 3D transforms can cause severe UI-thread stalls on the Fold8.
        // Create one smaller frozen frame for the animation instead.
        val frame = synchronized(copyLock) {
            val src = latestBitmap
            if (src == null) null else {
                val maxWidth = 1224
                val maxHeight = 924
                val scale = min(1f, min(maxWidth.toFloat() / src.width, maxHeight.toFloat() / src.height))
                val outW = (src.width * scale).toInt().coerceAtLeast(2)
                val outH = (src.height * scale).toInt().coerceAtLeast(2)
                Bitmap.createScaledBitmap(src, outW, outH, true)
            }
        }
        if (frame == null) {
            postStatus("HINGE MOVED: waiting for captured frame")
            moving = false
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            postStatus("Overlay permission is required")
            moving = false
            return
        }

        if (overlay == null) overlay = FoldOverlayView(this)
        animationBitmap?.recycle()
        animationBitmap = frame
        renderedHinge = lastHinge
        targetHinge = lastHinge
        overlay!!.setBitmap(animationBitmap!!)
        overlay!!.setHingeAngle(renderedHinge)
        if (!overlayAdded) {
            wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            try {
                wm!!.addView(overlay, lp)
                overlayAdded = true
            } catch (t: Throwable) {
                postStatus("OVERLAY ERROR: ${t.javaClass.simpleName}: ${t.message}")
                moving = false
                return
            }
        }
        overlay!!.alpha = 1f
        overlay!!.visibility = View.VISIBLE
    }

    private fun endAnimation() {
        moving = false
        targetHinge = lastHinge
        if (!overlayAdded) {
            frameCallbackPosted = false
            return
        }
        overlay?.animate()?.cancel()
        overlay?.alpha = 0f
        overlay?.visibility = View.GONE
        frameCallbackPosted = false
        animationBitmap?.recycle()
        animationBitmap = null
    }

    private fun startFrameLoop() {
        choreographer.postFrameCallback(object : Choreographer.FrameCallback {
            override fun doFrame(frameTimeNanos: Long) {
                if (!moving || !overlayAdded) {
                    frameCallbackPosted = false
                    return
                }
                val diff = targetHinge - renderedHinge
                renderedHinge += diff * 0.42f
                if (abs(diff) < 0.15f) renderedHinge = targetHinge
                overlay?.setHingeAngle(renderedHinge)
                choreographer.postFrameCallback(this)
            }
        })
    }

    private fun isFinishingOverlay(): Boolean = overlayAdded && overlay?.visibility == View.VISIBLE

    private fun postStatus(s: String) {
        main.post { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }
    }

    private fun notification(text: String): Notification =
        Notification.Builder(this, CH)
            .setContentTitle("FoldOpenFX")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()

    private fun stopCapture() {
        captureRunning = false
        try { sensorManager.unregisterListener(this) } catch (_: Throwable) {}
        try { if (overlayAdded) wm?.removeViewImmediate(overlay) } catch (_: Throwable) {}
        overlayAdded = false
        overlay = null
        animationBitmap?.recycle()
        animationBitmap = null
        frameCallbackPosted = false
        try { virtualDisplay?.release() } catch (_: Throwable) {}
        virtualDisplay = null
        try { reader?.close() } catch (_: Throwable) {}
        reader = null
        try { projection?.stop() } catch (_: Throwable) {}
        projection = null
        try { thread?.quitSafely() } catch (_: Throwable) {}
        thread = null
        handler = null
        synchronized(copyLock) {
            try { latestBitmap?.recycle() } catch (_: Throwable) {}
            latestBitmap = null
            compactBuffer = null
            compactCapacity = 0
            rowBuffer = null
        }
    }

    override fun onDestroy() {
        stopCapture()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private class FoldOverlayView(context: Context) : android.opengl.GLSurfaceView(context) {
        private val rendererImpl = FoldGlRenderer()

        init {
            setEGLContextClientVersion(2)
            setEGLConfigChooser(8, 8, 8, 8, 16, 0)
            holder.setFormat(PixelFormat.TRANSLUCENT)
            setZOrderOnTop(true)
            setRenderer(rendererImpl)
            renderMode = RENDERMODE_CONTINUOUSLY
        }

        fun setBitmap(b: Bitmap) {
            rendererImpl.setBitmap(b)
            requestRender()
        }

        fun setHingeAngle(a: Float) {
            rendererImpl.hinge = a.coerceIn(0f, 180f)
            requestRender()
        }

        fun clearBitmap() {
            rendererImpl.clearBitmap()
        }

        private class FoldGlRenderer : android.opengl.GLSurfaceView.Renderer {
            @Volatile var hinge: Float = 180f
            @Volatile private var pendingBitmap: Bitmap? = null
            private var texture = 0
            private var program = 0
            private var positionHandle = 0
            private var texCoordHandle = 0
            private var matrixHandle = 0
            private var alphaHandle = 0
            private val model = FloatArray(16)
            private val view = FloatArray(16)
            private val proj = FloatArray(16)
            private val vp = FloatArray(16)
            private val tmp = FloatArray(16)
            private val vertexBuffer = java.nio.ByteBuffer.allocateDirect(4 * 3 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
            private val texBuffer = java.nio.ByteBuffer.allocateDirect(4 * 2 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
            private var width = 1
            private var height = 1
            private var bitmapWidth = 1
            private var bitmapHeight = 1

            private val vertexShader = """
                attribute vec3 aPosition;
                attribute vec2 aTexCoord;
                uniform mat4 uMatrix;
                varying vec2 vTexCoord;
                void main() {
                    gl_Position = uMatrix * vec4(aPosition, 1.0);
                    vTexCoord = aTexCoord;
                }
            """.trimIndent()

            private val fragmentShader = """
                precision mediump float;
                uniform sampler2D uTexture;
                uniform float uAlpha;
                varying vec2 vTexCoord;
                void main() {
                    vec4 c = texture2D(uTexture, vTexCoord);
                    gl_FragColor = vec4(c.rgb, c.a * uAlpha);
                }
            """.trimIndent()

            fun setBitmap(b: Bitmap) {
                pendingBitmap = b
            }

            fun clearBitmap() {
                pendingBitmap = null
            }

            override fun onSurfaceCreated(gl: javax.microedition.khronos.opengles.GL10?, config: javax.microedition.khronos.egl.EGLConfig?) {
                android.opengl.GLES20.glClearColor(0f, 0f, 0f, 0f)
                android.opengl.GLES20.glEnable(android.opengl.GLES20.GL_BLEND)
                android.opengl.GLES20.glBlendFunc(android.opengl.GLES20.GL_SRC_ALPHA, android.opengl.GLES20.GL_ONE_MINUS_SRC_ALPHA)
                program = createProgram(vertexShader, fragmentShader)
                positionHandle = android.opengl.GLES20.glGetAttribLocation(program, "aPosition")
                texCoordHandle = android.opengl.GLES20.glGetAttribLocation(program, "aTexCoord")
                matrixHandle = android.opengl.GLES20.glGetUniformLocation(program, "uMatrix")
                alphaHandle = android.opengl.GLES20.glGetUniformLocation(program, "uAlpha")
                val ids = IntArray(1)
                android.opengl.GLES20.glGenTextures(1, ids, 0)
                texture = ids[0]
                android.opengl.GLES20.glBindTexture(android.opengl.GLES20.GL_TEXTURE_2D, texture)
                android.opengl.GLES20.glTexParameteri(android.opengl.GLES20.GL_TEXTURE_2D, android.opengl.GLES20.GL_TEXTURE_MIN_FILTER, android.opengl.GLES20.GL_LINEAR)
                android.opengl.GLES20.glTexParameteri(android.opengl.GLES20.GL_TEXTURE_2D, android.opengl.GLES20.GL_TEXTURE_MAG_FILTER, android.opengl.GLES20.GL_LINEAR)
                android.opengl.GLES20.glTexParameteri(android.opengl.GLES20.GL_TEXTURE_2D, android.opengl.GLES20.GL_TEXTURE_WRAP_S, android.opengl.GLES20.GL_CLAMP_TO_EDGE)
                android.opengl.GLES20.glTexParameteri(android.opengl.GLES20.GL_TEXTURE_2D, android.opengl.GLES20.GL_TEXTURE_WRAP_T, android.opengl.GLES20.GL_CLAMP_TO_EDGE)
                android.opengl.GLES20.glBindTexture(android.opengl.GLES20.GL_TEXTURE_2D, 0)
            }

            override fun onSurfaceChanged(gl: javax.microedition.khronos.opengles.GL10?, w: Int, h: Int) {
                width = w.coerceAtLeast(1)
                height = h.coerceAtLeast(1)
                android.opengl.GLES20.glViewport(0, 0, width, height)
                android.opengl.Matrix.setIdentityM(proj, 0)
                android.opengl.Matrix.orthoM(proj, 0, -1f, 1f, -1f, 1f, -4f, 4f)
                android.opengl.Matrix.setLookAtM(view, 0, 0f, 0f, 2.2f, 0f, 0f, 0f, 0f, 1f, 0f)
            }

            override fun onDrawFrame(gl: javax.microedition.khronos.opengles.GL10?) {
                android.opengl.GLES20.glClear(android.opengl.GLES20.GL_COLOR_BUFFER_BIT)
                val b = pendingBitmap
                if (b != null && !b.isRecycled) {
                    uploadBitmap(b)
                    pendingBitmap = null
                }
                if (texture == 0 || bitmapWidth <= 1 || bitmapHeight <= 1) return

                android.opengl.Matrix.multiplyMM(vp, 0, proj, 0, view, 0)
                val open = (hinge / 180f).coerceIn(0f, 1f)
                val fold = 1f - open
                val angle = fold * 90f

                // When the system switches to the narrow cover display, show the
                // cover-facing half of the same frozen frame. This is the visual
                // handoff rather than a page-turn.
                val imageAspect = bitmapWidth.toFloat() / bitmapHeight.toFloat()
                val viewAspect = width.toFloat() / height.toFloat()
                val coverMode = (1f / viewAspect) > imageAspect * 1.45f

                // When Android has switched to the narrow cover display, the
                // physical inner-screen fold is complete. Show the outward-facing
                // half of the frozen image briefly, then let the real cover display
                // take over. This is the key "mirror to the next screen" handoff.
                if (coverMode && fold > 0.72f) {
                    drawFull(0.5f, 1f)
                    return
                }

                // Both inner panels pivot around the real center hinge. At 180° the
                // panels are flat (0° rotation); at 0° each panel has rotated 90°
                // toward the hinge. This keeps the image continuous at the crease.
                drawHalf(true, 0f, 0.5f, angle)
                drawHalf(false, 0.5f, 1f, -angle)
            }

            private fun drawFull(u0: Float, u1: Float) {
                vertexBuffer.clear()
                vertexBuffer.put(floatArrayOf(-1f, -1f, 0f, 1f, -1f, 0f, -1f, 1f, 0f, 1f, 1f, 0f))
                vertexBuffer.position(0)
                texBuffer.clear()
                texBuffer.put(floatArrayOf(u0, 1f, u1, 1f, u0, 0f, u1, 0f))
                texBuffer.position(0)
                android.opengl.Matrix.setIdentityM(model, 0)
                android.opengl.Matrix.multiplyMM(tmp, 0, vp, 0, model, 0)
                android.opengl.GLES20.glUseProgram(program)
                android.opengl.GLES20.glUniformMatrix4fv(matrixHandle, 1, false, tmp, 0)
                android.opengl.GLES20.glUniform1f(alphaHandle, 1f)
                android.opengl.GLES20.glActiveTexture(android.opengl.GLES20.GL_TEXTURE0)
                android.opengl.GLES20.glBindTexture(android.opengl.GLES20.GL_TEXTURE_2D, texture)
                android.opengl.GLES20.glEnableVertexAttribArray(positionHandle)
                android.opengl.GLES20.glVertexAttribPointer(positionHandle, 3, android.opengl.GLES20.GL_FLOAT, false, 0, vertexBuffer)
                android.opengl.GLES20.glEnableVertexAttribArray(texCoordHandle)
                android.opengl.GLES20.glVertexAttribPointer(texCoordHandle, 2, android.opengl.GLES20.GL_FLOAT, false, 0, texBuffer)
                android.opengl.GLES20.glDrawArrays(android.opengl.GLES20.GL_TRIANGLE_STRIP, 0, 4)
                android.opengl.GLES20.glDisableVertexAttribArray(positionHandle)
                android.opengl.GLES20.glDisableVertexAttribArray(texCoordHandle)
            }

            private fun drawHalf(leftHalf: Boolean, u0: Float, u1: Float, rotationY: Float) {
                val x0 = if (leftHalf) -1f else 0f
                val x1 = if (leftHalf) 0f else 1f
                vertexBuffer.clear()
                vertexBuffer.put(floatArrayOf(x0, -1f, 0f, x1, -1f, 0f, x0, 1f, 0f, x1, 1f, 0f))
                vertexBuffer.position(0)
                texBuffer.clear()
                texBuffer.put(floatArrayOf(u0, 1f, u1, 1f, u0, 0f, u1, 0f))
                texBuffer.position(0)

                android.opengl.Matrix.setIdentityM(model, 0)
                // Pivot exactly on the center hinge. Right panel rotates outward/inward
                // around x=0 rather than around its own center.
                if (!leftHalf) {
                    android.opengl.Matrix.translateM(model, 0, 0f, 0f, 0f)
                    android.opengl.Matrix.rotateM(model, 0, rotationY, 0f, 1f, 0f)
                }
                android.opengl.Matrix.multiplyMM(tmp, 0, vp, 0, model, 0)

                android.opengl.GLES20.glUseProgram(program)
                android.opengl.GLES20.glUniformMatrix4fv(matrixHandle, 1, false, tmp, 0)
                android.opengl.GLES20.glUniform1f(alphaHandle, 1f)
                android.opengl.GLES20.glActiveTexture(android.opengl.GLES20.GL_TEXTURE0)
                android.opengl.GLES20.glBindTexture(android.opengl.GLES20.GL_TEXTURE_2D, texture)
                android.opengl.GLES20.glEnableVertexAttribArray(positionHandle)
                android.opengl.GLES20.glVertexAttribPointer(positionHandle, 3, android.opengl.GLES20.GL_FLOAT, false, 0, vertexBuffer)
                android.opengl.GLES20.glEnableVertexAttribArray(texCoordHandle)
                android.opengl.GLES20.glVertexAttribPointer(texCoordHandle, 2, android.opengl.GLES20.GL_FLOAT, false, 0, texBuffer)
                android.opengl.GLES20.glDrawArrays(android.opengl.GLES20.GL_TRIANGLE_STRIP, 0, 4)
                android.opengl.GLES20.glDisableVertexAttribArray(positionHandle)
                android.opengl.GLES20.glDisableVertexAttribArray(texCoordHandle)
            }

            private fun uploadBitmap(b: Bitmap) {
                bitmapWidth = b.width
                bitmapHeight = b.height
                android.opengl.GLES20.glBindTexture(android.opengl.GLES20.GL_TEXTURE_2D, texture)
                android.opengl.GLUtils.texImage2D(android.opengl.GLES20.GL_TEXTURE_2D, 0, b, 0)
                android.opengl.GLES20.glBindTexture(android.opengl.GLES20.GL_TEXTURE_2D, 0)
            }

            private fun createProgram(vs: String, fs: String): Int {
                val v = compile(android.opengl.GLES20.GL_VERTEX_SHADER, vs)
                val f = compile(android.opengl.GLES20.GL_FRAGMENT_SHADER, fs)
                val p = android.opengl.GLES20.glCreateProgram()
                android.opengl.GLES20.glAttachShader(p, v)
                android.opengl.GLES20.glAttachShader(p, f)
                android.opengl.GLES20.glLinkProgram(p)
                val ok = IntArray(1)
                android.opengl.GLES20.glGetProgramiv(p, android.opengl.GLES20.GL_LINK_STATUS, ok, 0)
                if (ok[0] == 0) throw RuntimeException("GL link failed: " + android.opengl.GLES20.glGetProgramInfoLog(p))
                android.opengl.GLES20.glDeleteShader(v)
                android.opengl.GLES20.glDeleteShader(f)
                return p
            }

            private fun compile(type: Int, source: String): Int {
                val s = android.opengl.GLES20.glCreateShader(type)
                android.opengl.GLES20.glShaderSource(s, source)
                android.opengl.GLES20.glCompileShader(s)
                val ok = IntArray(1)
                android.opengl.GLES20.glGetShaderiv(s, android.opengl.GLES20.GL_COMPILE_STATUS, ok, 0)
                if (ok[0] == 0) throw RuntimeException("GL shader failed: " + android.opengl.GLES20.glGetShaderInfoLog(s))
                return s
            }
        }
    }
}
