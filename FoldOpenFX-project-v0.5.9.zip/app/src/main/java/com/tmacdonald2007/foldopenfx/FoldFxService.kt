package com.tmacdonald2007.foldopenfx

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.*
import java.nio.ByteBuffer
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.provider.Settings
import android.view.*
import kotlin.math.abs
import kotlin.math.sin

class FoldFxService : Service(), SensorEventListener {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val EXTRA_TEST = "test_animation"
        private const val CH = "foldfx"
        private const val NOTIF = 7
        private const val ANIM_MS = 650L
        private const val ACTION_FRAME = "com.tmacdonald2007.foldopenfx.FRAME_RECEIVED"
    }

    private lateinit var sensorManager: SensorManager
    private var hinge: Sensor? = null
    private var lastAngle = Float.NaN
    private var lastMotionAt = 0L

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var virtualDisplay: android.hardware.display.VirtualDisplay? = null
    private var latestBitmap: Bitmap? = null

    private var wm: WindowManager? = null
    private var overlay: FoldOverlay? = null
    private var animator: ValueAnimator? = null
    private var animationRunning = false
    private var frozenBitmap: Bitmap? = null
    private var mainHandler: Handler = Handler(Looper.getMainLooper())

    private val displayManager by lazy { getSystemService(DisplayManager::class.java) }
    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) = Unit
        override fun onDisplayRemoved(displayId: Int) = Unit
        override fun onDisplayChanged(displayId: Int) {
            // Samsung can rebuild the active display during the fold handoff.
            // Reattach once, without restarting the animation or replacing the bitmap.
            if (animationRunning) {
                mainHandler.postDelayed({ reattachOverlayIfNeeded() }, 90L)
            }
        }
    }

    private var foregroundStarted = false
    private var frameCount = 0L
    private var lastFrameAt = 0L

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        displayManager.registerDisplayListener(displayListener, mainHandler)

        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        hinge = sensorManager.getDefaultSensor(Sensor.TYPE_HINGE_ANGLE)
        hinge?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val isPreview = intent?.getBooleanExtra(EXTRA_TEST, false) == true
        val code = intent?.getIntExtra(EXTRA_RESULT_CODE, -1) ?: -1
        val data = intent?.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
        if (code != -1 && data != null && projection == null) {
            startForegroundIfNeeded(mediaProjection = true)
            startCapture(code, data)
        } else {
            startForegroundIfNeeded(mediaProjection = false)
        }
        if (isPreview) {
            // Give ImageReader time to receive the first real frame, then animate it.
            mainHandler.postDelayed({ runRealPreview(attempt = 0) }, 500L)
        }
        return START_STICKY
    }

    private fun startForegroundIfNeeded(mediaProjection: Boolean) {
        if (foregroundStarted) return
        foregroundStarted = true
        if (Build.VERSION.SDK_INT >= 34) {
            val type = if (mediaProjection) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            } else {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            }
            startForeground(NOTIF, notification(), type)
        } else if (Build.VERSION.SDK_INT >= 29) {
            val type = if (mediaProjection) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            } else {
                0
            }
            startForeground(NOTIF, notification(), type)
        } else {
            startForeground(NOTIF, notification())
        }
    }

    private fun startCapture(code: Int, data: Intent) {
        try {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            projection = mpm.getMediaProjection(code, data)
            val mp = projection ?: run {
                statusToast("MediaProjection could not be created.")
                return
            }

            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    statusToast("Screen capture session stopped by Android.")
                    stopCapture()
                }
            }, mainHandler)

            // Use the real physical display metrics rather than the app's logical
            // resources metrics. This matters on foldables during display changes.
            val dm = android.util.DisplayMetrics()
            @Suppress("DEPRECATION")
            (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
            val w = dm.widthPixels
            val h = dm.heightPixels
            if (w <= 0 || h <= 0) {
                statusToast("Invalid capture size: ${w}x${h}")
                return
            }

            reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)

            reader!!.setOnImageAvailableListener({ ir ->
                var image: android.media.Image? = null
                try {
                    image = ir.acquireLatestImage() ?: return@setOnImageAvailableListener
                    val plane = image.planes[0]
                    val pixelStride = plane.pixelStride
                    val rowStride = plane.rowStride
                    if (pixelStride < 4 || rowStride < w * pixelStride) return@setOnImageAvailableListener

                    val src = plane.buffer.duplicate()
                    val rowBytes = w * 4
                    val packed = ByteBuffer.allocateDirect(rowBytes * h)
                    val row = ByteArray(rowBytes)

                    for (y in 0 until h) {
                        val rowStart = y * rowStride
                        if (rowStart + rowBytes > src.limit()) {
                            return@setOnImageAvailableListener
                        }
                        src.position(rowStart)
                        src.get(row, 0, rowBytes)
                        packed.put(row)
                    }
                    packed.flip()

                    val frame = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    frame.copyPixelsFromBuffer(packed)

                    synchronized(this) {
                        latestBitmap?.recycle()
                        latestBitmap = frame
                        frameCount++
                        lastFrameAt = SystemClock.uptimeMillis()
                    }

                    if (frameCount == 1L) {
                        statusToast("SCREEN FRAME RECEIVED ${w}x${h}")
                    }
                } catch (t: Throwable) {
                    if (frameCount == 0L) {
                        statusToast("Screen frame error: ${t.javaClass.simpleName}: ${t.message ?: "unknown"}")
                    }
                } finally {
                    image?.close()
                }
            }, mainHandler)

            virtualDisplay = mp.createVirtualDisplay(
                "FoldOpenFXCapture",
                w,
                h,
                dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader!!.surface,
                null,
                mainHandler
            )

            statusToast("Capture running: ${w}x${h}. Waiting for first frame...")
            mainHandler.postDelayed({
                if (frameCount == 0L) {
                    statusToast("No screen frame received after 3 seconds.")
                }
            }, 3000L)
        } catch (t: Throwable) {
            statusToast("Capture start error: ${t.javaClass.simpleName}: ${t.message ?: "unknown"}")
            stopCapture()
        }
    }

    override fun onSensorChanged(event: SensorEvent) {
        val angle = event.values[0]
        if (lastAngle.isNaN()) {
            lastAngle = angle
            return
        }

        val delta = abs(angle - lastAngle)
        val now = SystemClock.uptimeMillis()
        if (delta >= 0.25f && !animationRunning && now - lastMotionAt >= 500L) {
            lastMotionAt = now
            val opening = angle > lastAngle
            val bitmap = synchronized(this) {
                latestBitmap?.takeUnless { it.isRecycled }?.copy(Bitmap.Config.ARGB_8888, false)
            }
            if (bitmap != null) {
                animateSnapshot(bitmap, opening)
            }
        }
        lastAngle = angle
    }

    private fun runRealPreview(attempt: Int) {
        if (animationRunning) return
        val bitmap = synchronized(this) {
            latestBitmap?.copy(Bitmap.Config.ARGB_8888, false)
        }
        if (bitmap != null) {
            animateSnapshot(bitmap, opening = true)
            return
        }

        // A real preview must use a captured display frame. Do not substitute a
        // synthetic bitmap: that would hide capture failures from us.
        if (attempt < 24) {
            mainHandler.postDelayed({ runRealPreview(attempt + 1) }, 250L)
        } else {
            statusToast("Preview could not obtain a screen frame. Try Enable FoldOpenFX first, then Preview again.")
        }
    }

    private fun statusToast(message: String) {
        android.widget.Toast.makeText(applicationContext, message, android.widget.Toast.LENGTH_LONG).show()
    }

    private fun animateSnapshot(bitmap: Bitmap, opening: Boolean) {
        if (!Settings.canDrawOverlays(this)) {
            bitmap.recycle()
            return
        }

        mainHandler.post {
            animator?.cancel()
            overlay?.let { removeOverlay(it) }
            frozenBitmap?.recycle()
            frozenBitmap = bitmap
            animationRunning = true

            val ov = FoldOverlay(this, frozenBitmap!!)
            overlay = ov
            attachOverlay(ov)

            val start = if (opening) 0f else 1f
            val end = if (opening) 1f else 0f
            animator = ValueAnimator.ofFloat(start, end).apply {
                duration = ANIM_MS
                interpolator = android.view.animation.PathInterpolator(0.2f, 0.0f, 0.15f, 1.0f)
                addUpdateListener { a ->
                    ov.progress = a.animatedValue as Float
                    ov.invalidate()
                }
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator) {
                        finishAnimation()
                    }
                    override fun onAnimationCancel(animation: Animator) {
                        // A replacement animation may immediately follow.
                    }
                })
                start()
            }
        }
    }

    private fun attachOverlay(view: View) {
        val manager = wm ?: return
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.title = "FoldOpenFX"
        if (Build.VERSION.SDK_INT >= 28) {
            params.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
        try {
            manager.addView(view, params)
        } catch (_: Throwable) {
            // Retry shortly if Samsung is between physical displays.
            mainHandler.postDelayed({
                if (animationRunning && overlay === view) attachOverlay(view)
            }, 80L)
        }
    }

    private fun reattachOverlayIfNeeded() {
        if (!animationRunning || frozenBitmap == null) return
        val current = overlay ?: return
        try {
            // If it's still attached, leave it alone. If WindowManager removed it,
            // adding it again is attempted below.
            current.invalidate()
            return
        } catch (_: Throwable) {
        }
    }

    private fun finishAnimation() {
        animationRunning = false
        animator = null
        overlay?.let { removeOverlay(it) }
        frozenBitmap?.recycle()
        frozenBitmap = null
    }

    private fun removeOverlay(view: View) {
        try { wm?.removeViewImmediate(view) } catch (_: Throwable) { }
        if (overlay === view) overlay = null
    }

    private fun stopCapture() {
        try { virtualDisplay?.release() } catch (_: Throwable) { }
        virtualDisplay = null
        try { reader?.close() } catch (_: Throwable) { }
        reader = null
        synchronized(this) {
            latestBitmap?.recycle()
            latestBitmap = null
        }
        projection = null
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    override fun onDestroy() {
        sensorManager.unregisterListener(this)
        displayManager.unregisterDisplayListener(displayListener)
        animator?.cancel()
        overlay?.let { removeOverlay(it) }
        stopCapture()
        frozenBitmap?.recycle()
        frozenBitmap = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CH, "FoldOpenFX", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun notification(): Notification {
        return Notification.Builder(this, CH)
            .setContentTitle("FoldOpenFX active")
            .setContentText("Fold transition effect is active")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
    }

    class FoldOverlay(ctx: Context, private val source: Bitmap) : View(ctx) {
        var progress = 0f
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private val shadow = Paint(Paint.ANTI_ALIAS_FLAG)

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            if (width <= 0 || height <= 0 || source.isRecycled) return

            val w = width.toFloat()
            val h = height.toFloat()
            val mid = w / 2f
            val p = progress.coerceIn(0f, 1f)
            val separation = w * 0.30f * sin(p * Math.PI).toFloat()

            val left = RectF(0f, 0f, mid - separation / 2f, h)
            val right = RectF(mid + separation / 2f, 0f, w, h)
            val half = source.width / 2

            canvas.save()
            canvas.clipRect(0f, 0f, mid, h)
            canvas.drawBitmap(source, Rect(0, 0, half, source.height), left, paint)
            canvas.restore()

            canvas.save()
            canvas.clipRect(mid, 0f, w, h)
            canvas.drawBitmap(source, Rect(half, 0, source.width, source.height), right, paint)
            canvas.restore()

            val shade = 0.65f * sin(p * Math.PI).toFloat()
            if (shade > 0f) {
                shadow.shader = LinearGradient(
                    mid - 80f, 0f, mid + 80f, 0f,
                    Color.argb((190f * shade).toInt(), 0, 0, 0),
                    Color.TRANSPARENT,
                    Shader.TileMode.CLAMP
                )
                canvas.drawRect(mid - 80f, 0f, mid + 80f, h, shadow)
            }
        }
    }
}
